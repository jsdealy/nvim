local M = {}

function Capture_command_output(command)
    local file = io.popen(command)  -- Run command and capture output
    if file == nil then return "error" end
    local output = file:read("*all") -- Read all of the file's content
    file:close()
    return output
end

function ZathuraOpen(filename)
    if string.find(Capture_command_output("ps -e | grep zathura"), "zathura") == nil then
	local pdffilename, subsmade = filename:gsub("tex", "pdf")
	if subsmade == 1 then os.execute("zathura " .. pdffilename .. " &")
	    else print("zathura is already running...") end
    end
end

function Pandocomatic(args)

    local push = false
    local latex = false
    local filename = vim.g.filename_for_pandoc or vim.api.nvim_buf_get_name(0)
    if args ~= nil then
	push = args.push or false
	latex = args.latex or false
    end

    local temp = Capture_command_output("mktemp")
    local temp2 = Capture_command_output("mktemp")

    local command = ""
    if latex then command = "latexmk -pdf -f " .. filename .. " &> " .. temp
    else command = "mdcomment '" .. filename .. "' > output.md && pandocomatic output.md &> " .. temp end

    -- Execute the shell command
    local exitCode1 = 0
    local gitstatus = Capture_command_output("git status")
    local backingup = false
    if gitstatus:find("nothing to commit") == nil then
	backingup = true
	vim.api.nvim_command("Git add -A")
	vim.api.nvim_command("Git commit -m 'update'")
	if push then vim.api.nvim_command("Git push origin master") end
---@diagnostic disable-next-line: cast-local-type
	exitCode1 = os.execute("bb -s &>" .. temp2)
    end

    -- executing the main command <= 10/07/23 16:05:30 -- 
    local exitCode2 = os.execute(command)

    -- Check the exit code to determine if the command was successful
    if ((backingup and exitCode1 == 0) or not backingup) and exitCode2 == 0 then
	print("Commands executed successfully")
	-- opening zathura if it isn't already open <= 10/07/23 12:13:49 -- 
	ZathuraOpen(filename)
    elseif exitCode1 ~= 0 then
	if backingup then
	    print("bb failed with exit code:", exitCode1)
	    os.execute("cat " .. temp2)
	end
    elseif exitCode2 ~= 0 then
	if latex then print("latexmk exited with code:", exitCode2)
	else print("mdcomment or pandocomatic failed with exit code:", exitCode2) end
	if latex then
	    local grepsuccess = Capture_command_output("grep 'Output written on' " .. filename:gsub("tex", "log")):find("Output written on")
	    if grepsuccess == nil then vim.api.nvim_command("edit " .. filename:gsub("tex", "log"))
	    else
		print("latexmk had warnings, but produced a pdf...")
		ZathuraOpen(filename)
	    end
	end
    end
end

return M
