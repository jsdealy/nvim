---
fontsize: 12pt
title: On Giving Yourself a Sign
#subtitle: Desire, Subjective Practical Reasons, and Decision Theory
author: Anonymous
#fontfamily: times
mainfont: Times New Roman
sansfont: Helvetica
lang: en-GB
##documentclass: memoir
##classoption: article
documentclass: article
#papersize: a4
linestretch: 1.5
mathfont: XITS Math
keywords: [Subjective Practical Reasons, Practical Reason, Intrinsic Desire, Instrumental Desire, Instrumental Reason, Causal Decision Theory] 
geometry: 
- margin=1in
reference-section-title: Bibliography
#secPrefix: "§\\hspace{-0.25em}"
header-includes: |
 \usepackage{float}
 \floatplacement{figure}{H}
 \usepackage{unicode-math}
 \usepackage[normalem]{ulem}
 \usepackage{xcolor}
 \usepackage{xfrac}
 \usepackage{amssymb}
 \usepackage{abstract}
 \setlength{\parindent}{1em}
 \setcounter{section}{-1} 	
#\usepackage[pagecolor={cyan}]{pagecolor}
pandocomatic:
 use-template: 
 - md-to-pdf
...

\begin{abstract}I argue we can have subjective
practical reasons to perform 
actions we do not think are morally required
and that we do not think are 
means to satisfy our intrinsic desires. These
reasons are grounded in extrinsic desires. 
Specifically, my claim is that subjective practical 
reasons can be grounded in 
desires for signs (i.e., signatory desires), a species of extrinsic desire, 
together with means-end beliefs. 
These reasons act like any other subjective
practical reason, except when they are trumped, 
which, I argue, can happen when they are 
competition with a subjective practical reasons
grounded in intrinsic desire. 
\end{abstract}

\noindent \textbf{Keywords:} Practical Reason, Subjective Reasons, 
Intrinsic and Extrinsic Desire

# Introduction # { #sec:}

Sometimes we want a sign.
We gaze heavenward hoping to 
spot some sign from a higher power. 
We scrutinize text messages
for signs of affection.
We peek into hot ovens hoping to see
signs that our attempt at baking 
is going well. And so on. Consider something
weird: suppose you want a 
sign and you believe you can *manifest it*---or to 
put it precisely, you believe
you can do something to make that sign happen, and it will
*retain its desired significance as a sign*. 
This is not normally how it works. We do not 
usually go around trying to manifest 
desirable signs of things we hope 
for, since we know in advance
that our best effort would
only produce a dud lacking the desired
significance.\footnote{Doctoring your 
text message logs won't give you any evidence
that your crush likes you, alas.}
But in the weird case where you can create the 
sign you want and still have it mean what 
you want it to mean, do you 
necessarily have a practical reason to
do so? I will argue on the basis
of a straightforward means-end principle  that the
answer is Yes, provided that we understand 'reason'
subjectively ([@Sec:mescwalter]). This
result is intriguing in itself, but 
what makes it 
especially noteworthy is that such reasons are 
grounded in a species of extrinsic desire
(i.e., desires for signs) that can exist even when you do not 
believe you have means to satisfy
any intrinsic desires---not even the intrinsic
desire(s) from which the extrinsic desire 
derives. In other words, desires for signs can 
give rise to practical reasons that do not bottom out
in the aim to satisfy intrinsic desire. 
After responding to objections ([@Sec:objections]), I
argue that the 
reasons grounded in desires for 
signs can be *trumped* by reasons
grounded in intrinsic desires. 
I sketch a *Two-level
Means-end Account* of subjective desire-based
reasons meant codify all this ([@Sec:tla]). 

# Setup and Background # { #sec:setup}

## Objective and Subjective Practical Reasons ## { #sec:obsubintro}

Assertions to the effect that so-and-so has a reason to do such-and-such can be
heard "objectively" or "subjectively."  Bernie thinks his glass contains gin
and tonic when in fact it's filled with gasoline [@williams_internal_1979].
Bernie wants to drink gin and tonic, not gasoline---does he have any reason to
take a sip? On one way of hearing the question (the "objective" way), the
answer is No. On another way of hearing the question (the "subjective" way),
the answer is Yes. A natural account of this is that our ordinary talk about
having reasons to do things---practical reason talk---is ambiguous.  There are
two different sorts of practical reason our talk can be about, depending on how
it is disambiguated: objective practical reasons or subjective practical
reasons. Bernie has no objective practical reason to take a sip, but 
he does have a 
subjective practical reason to take a sip.

Some philosophers deny both the ambiguity  and
the existence of subjective practical reasons
[@DancyRTMSSOTP; see also @ThomsonIR]. Others
say that while Bernie has an "apparent"
practical reason to take a sip, he in fact has
no practical reason to take a sip [@ParfitRAR;
@ParfitOWMV1; @SylvanWARATB; @SylvanRROAR].
Still others [@MackieEthics, 77; @JoyceMOM;
@SchroederSLOP; @SchroederHR; @SchroederGPOOR\;
etc.], myself included, grant the ambiguity and
the existence of subjective practical
reasons. This paper is primarily addressed to
those in the second and third camps, i.e.,
those who in some sense countenance subjective
practical reasons.[^fn1] Naturally, members of
the first camp are invited to read on in
the spirit of understanding the opposition.

### The Means-End Principle ### { #sec:mep}



I will be assuming the following:

Means-end Principle [(MEP):]{id="mep"}

: An agent S has a subjective practical reason, grounded in a belief B and
desire D, to do option O iff D is a desire of S's with content *p* and B is a
belief of S's that doing O is (or might be) a means to the truth of *p*.[^fn2]

MEP captures a means-end view of
subjective reasons that is relatively
modest inasmuch as it is compatible with such reasons
having sources other than desire. What it
denies is the possibility of a subjective
reason grounded in a belief-desire complex
where the belief is not means-end.[^fn3]   On
this view, if an agent wants something, and
believes  one of their options is a means to
that thing, then those facts give rise
to a subjective reason for them to do that
option, and that is the only way a belief and
desire can work together to ground a subjective
reason. 

MEP offers a natural explanation of  Bernie's  having a subjective reason to take a sip. Bernie wants to drink gin and tonic and  believes taking a sip is a means to that. Thus, he has a subjective reason to take a sip grounded in his means-end belief and desire.


### The Constitutive Roles of Subjective Practical Reasons ### { #sec:roles}

Subjective reasons play constitutive roles vis-à-vis rationality [@SchroederSLOP; @SchroederHR; @WodakCOAFSR]. Three such roles will be relevant.

The core role  has to do with rational action. It can be stated simply with the following principle: 

Act [Rationality:]{id="ar"} 

: An action is rational  iff (and because) the subjective practical reasons to do it are not outweighed by the subjective practical reasons to do otherwise.

A second role played by subjective reasons has to do with rational criticism [@SchroederSLOP; @WodakCOAFSR]. Roughly put, our practices of rationally criticizing agents for their actions or  deliberations are constitutively bound up with perceived failures to   suitably  respond to  subjective reasons. The following two principles capture this: 

Act [Criticizability:]{id="ac"} 

: An agent is rationally criticizable for doing an act A iff (and because) whatever subjective practical reason(s) they have to do A are outweighed by the subjective practical reason(s) they have to do one of their alternative options. 

Deliberation [Criticizability:]{id="dc"}

: An agent's practical deliberation is rationally criticizable iff (and because) they failed to suitably appreciate, individually or collectively, some of the subjective practical reasons they have for or against one of their options.[^fn4]

A third role played by subjective reasons has to do with rational motivation [@SchroederSLOP; @SchroederHR].   I'll rely on the following plausible necessary condition: 

Rational Movement [Condition:]{id="rmc"}

: An agent is in a position to be rationally moved by a belief B and desire D to do one of their options O only if they have a subjective practical reason R, grounded in B and D, to do O.[^fn5] 

Being rationally moved by a belief B and desire D to do O is at least materially equivalent to doing O and having a *motivating reason* grounded in B and D. Motivating reasons are reasons that are *acted on*---reasons *for which* an agent does an action. They are not mere causes of action. They *rationalize *action, in the sense of @DavidsonARC.  Subjective reasons are what rationalize actions; to act and have a motivating reason is to act on a subjective reason one has.

## Desire ## { #sec:desire}

Subjective reasons are one main element in this paper; the other is desire. I will assume that desires are propositional attitudes in the sense that a token desire with  content *p* is essentially such that it is *satisfied* iff *p* is true.
So for example, where we might ordinarily speak of Scooby wanting a club sandwich, I will understand Scooby as desiring that Scooby has a club sandwich. Having made this clear,  I'll sometimes state things in a way superficially inconsistent with it when doing so is convenient for presentation.

### Intrinsic and Extrinsic Desires ### { #sec:intex}

To intrinsically desire something  is to desire it in and of itself, for its
own sake. To extrinsically desire something is to desire it for the sake of
some further, logically distinct thing. Intrinsic desire is logically
independent of extrinsic desire; you can have or not have an 
intrinsic desire for something you extrinsically desire. 

### Extrinsic Desires are Derivative ### { #sec:deriving}

Extrinsic desires are *derivative*. They
typically  derive from other desires in virtue
of "connecting beliefs," e.g., a belief that if
an extrinsic desire is satisfied some further
desire will be satisfied  [@smithmp, pp. 157;
@SmithIDIR; @ArpalySchoederIPOD].  The claim
that extrinsic desires are derivative can be
unpacked in two ways. First, extrinsic desires
tend to vanish if and when the beliefs in
virtue of which they derive  are lost---e.g.,
if Joe the health nut stops believing that
exercise causes health his desire to
exercise vanishes. Second, extrinsic desires
are---at least stereotypically---*rationally
explainable* by appeal to further desires
(i.e.,  those from which they derive) together
with beliefs (i.e.,  those in virtue of which
they derive).  Rational explanation in this
context is not merely causal. We ask questions
like  "Why do you want to go to med school?"
and  expect answers like "I want to become a
doctor and (I believe) going to med school is a
means to that" which intuitively differ
substantially from answers like "I was
brainwashed."\footnote{Exceptions to the 
letter (but not the spirit) of this characterization 
of extrinsic desires come from cases of 
desires for knowledge. I'll discuss these cases in @Sec:sdk.}

### Signatory Desire ### { #sec:evidential}

The key type of desire in this paper is a
species of non-instrumental extrinsic desire that
@McDanielBradleyDesires have dubbed *signatory*
desire.[^fn7]  Consider Tom, who just texted
his crush Judy and asked if she's into him.
Tom very much wants to receive a text   that
reads "Yes." Tom's desire for a "Yes" is not
intrinsic, but neither does he believe a "Yes"
would be a means to anything else he wants. He
only wants it because it would be a sign that
Judy reciprocates his feelings.  His desire for
the text is signatory.



The following definition  will suffice for our purposes: 

Signatory Desire:

: A desire D for *p* is signatory iff there is some *q* such that D derives from a desire for *q* in virtue of a belief that *p*'s truth is a sign (but not a cause) of *q*'s truth.[^fn8]

Being a sign but not a cause is a  familiar notion. The failure of the bathtub to drain is a sign but not a cause of a clog in the pipe. A persistent cough is a sign but not a cause of an infection. I will not attempt to analyze this notion.

### Desire's Causal Roles ### { #sec:droles}

Desire's roles in folk psychology include but aren't limited to motivating and rationalizing action in combination with belief [cf. @SinhababuHTMRD; for methodological background, see @Braddon-MitchellNolaICP]. Here are five more causal roles. First, the believed satisfaction or frustration of desire is causally tied to pleasure, displeasure, and related feelings and attitudes: coming to believe a desire is or will be satisfied causes pleasure (or excitement, relief, contentment, etc.), whereas coming to believe a desire is or will be frustrated causes displeasure (or disappointment, sadness, annoyance, etc.). Second, desires cause one to fantasize about their objects and dwell on what it is about their objects that is desired [cf. @ScanlonWWOEO, 38].[^fn9] Third, desires direct our attention to things in our environment associated with their objects. Fourth, desires can be intensified by dwelling on vivid representations of their objects. Fifth, desires cause a distinctive phenomenological feel (a "pull") vis-à-vis their objects.

### Idle Desire and Working Desire ### { #sec:workingd}

Both of the following sentences are true: 

1) I want a new car. 
2) I want it to be the case that both (i) I have a new car and (ii) there are an even number of hairs on my head. 

But only the content attributed by the first of these sentences is such that a
mental state with that content  plays the causal roles of desire in my
psychology (viz., I will not be the least bit let down if I come to believe I'm
getting a new car but have an odd number of head hairs; I fantasize
occasionally about having a new car, but never about the conjunction of that
and my having an even number of hairs; etc.).  So, we mustn't assume a one-one
correspondence between an agent's desires and true attributions of desire to
said agent. 

Why is 2) true? Is it because I have a desire whose content is entailed by the conjunctive content 2) attributes? No.  Ralph is an American seven-year-old. It is natural to think the first but not the second of the following is true: 

3) Ralph wants a new toy. 
4) Ralph wants it to be the case that both (i) he has a new toy and (ii) vaquitas love knafeh. 

It's natural to think 4) can be false despite 3) being true because Ralph might have never heard of vaquitas or knafeh---he might not possess the required concepts.[^fn10] 

Why then is 2) true? Here is why: the subject of 2)---i.e., me---happens to believe the truth of the content attributed in 2) is a means to (and/or a sign of) the truth of the content attributed in 1), which in turn is the content of one of my desires. 




What is it that prevents us from saying that I have a desire with satisfaction condition attributed by 2)? Just  some causal constraint on positing psychological states. If we do not mind violating such a constraint, we can *stipulate* a one-one correspondence between true desire attributions and desires. As it turns out, doing this will be useful for us. We will simply keep in mind the distinction between the stipulated states and the states that actually play the causal roles of desire.[^fn11] Call the stipulated states *idle desires* and the states that play the causal roles of desire *working desires.* Only working desires can be intrinsic; idle desires are by nature  extrinsic. 

Idle desires cannot ground subjective practical reasons. In particular, [MEP](#mep) and other principles quantifying over desires are meant to quantify only over working desires.[^fn12] Henceforth, all my reference to desire will be confined to working desire, unless stated otherwise.

### Are Signatory Desires Just Desires for Knowledge? ### { #sec:sdk}

Perhaps signatory desires are nothing more than desires for knowledge.[^fn13]  That is, perhaps 

Signatory Desires are Desires for Knowledge (SDK): 

: To have a signatory desire for the truth of *p* is just to have a desire to know whether (or that) *p*. 

For instance, perhaps Tom doesn't want a "Yes"
text to appear on his phone, strictly speaking.
Rather, perhaps what he really wants is to
*know* whether (or that) a "Yes" has appeared,
or to *know* whether (or that) Judy likes him.
SDK says this is what signatory 
desire just is.
I think SDK is false for two reasons. 

The first reason is just that we can
imagine cases where someone wants a sign but
clearly doesn't want the associated knowledge. 
Examples that come to mind 
are weird but intelligible.
Patrick the alligator-lover believes an Amazing
Predictor spared an alligator's life iff she
predicted rain in 
Bangkok tomorrow and that Patrick will
never know about it.[^fn14] Patrick hopes for
rain in Bangkok tomorrow, but he 
does not want to know about it.

A second reason to think
SDK is false is that agents can give up hope of
knowing whether a sign obtains without giving
up hope that it does. Damon is a dying man who
wants it to be the case that Atlantis existed.
He therefore wants it to be the case that
Atlantean artifacts exist somewhere at the
bottom of the Atlantic. Damon has given up hope
of ever knowing whether there are Atlantean
artifacts, but he has not given up hope that
there are such artifacts. If one can give up
hope of Desire A being satisfied while not
giving up hope of Desire B being satisfied,
then it seems Desire A and Desire B must be
distinct.

I'm persuaded by cases like Patrick's
and Damon's, but it's not essential to my purposes
that SDK be false. As far as the arguments 
I'm going to give go, what's necessary is just that 
signatory desires are not 
as a rule believed to be means to 
satisfying intrinsic desire.  So, would SDK
being true throw a wrench into my arguments?
There are two ways it could. First, it could be
that any time one believes an option is a means
to desired knowledge, 
one also believes it is a means
to some intrinsic desire. 
Second, it could be that desires for
knowledge of signs are intrinsic any time the
desired knowledge is
believed not to be a means to further desire
satisfaction.  I'll consider these
possibilities in order.   

Suppose Terry's only intrinsic desire is to
love and to be (and to have been) loved. Terry
desires to know whether his 
deceased relative really loved him. He believes
he can gain this knowledge if he reads a
special letter they wrote to him. It seems 
coherent to suppose that Terry does
not believe reading the letter would be a
means to loving or to being loved.[^fn16]
Cases like this show that believing *x*
is a means to desired knowledge doesn't
imply believing *x* is a means to
intrinsic desire. 


Is all desire for knowledge intrinsic? 
Clearly not.[^fn17] But what about desires to know
whether mere signs obtain, where one
believes that that knowledge
is not a means to any further desire---are all
*those* desires intrinsic? 
Consider a concrete example. 
We ask Yancy why he wants
to know whether canaries have been dying in the
coal mine. He answers, "Because
that would be a sign of dangerous carbon monoxide levels, and I do not
want the miners getting poisoned." Note that
Yancy can desire the canary knowledge even if he 
knows he can do nothing to stop miners getting
carbon monoxide poisoning. Now, assuming Yancy has no other
reasons for caring about canaries, the
intensity of his desire to know whether
canaries are dying will vary with his concern
for carbon monoxide levels in the mine and his confidence
that canary deaths are a sign. Further,
Yancy's desire for the knowledge will be
rationally explainable via his concern over
carbon monoxide levels and his belief that canary deaths are
a sign about that. So, desires to know
whether signs obtain can be extrinsic, even 
when such knowledge is
believed not to be a means to further desire
satisfaction.\footnote{Two tangential observations 
seem in order here. First, it's
interesting to note that the way desires to
know whether signs obtain derive  seems
structurally different from the way  desires
for means derive. In the latter case one's
belief is that the thing desired stands in a
means-end relation to some further thing one
desires; but in the former case one's belief is
not that the knowledge one desires stands in
the is-a-sign-of relation to some further thing
one desires, but rather that the content of
the knowledge desired stands in that relation.
Second, it seems a desire for knowledge can be
extrinsic without deriving in virtue of \emph{any}
belief. If one wants a particular fact to
obtain one can, in virtue of that alone,
desire to know whether it obtains; desire for
such knowledge seems extrinsic insofar as it
waxes and wanes with, and is explained by,
one's concern for the particular state of
affairs.}


# Signatory Desires Ground Subjective Practical Reasons # { #sec:mescwalter}

The preceding section familiarized us with signatory desires, 
subjective practical reasons, and the Means-end 
Principle. In this section I connect the dots. 
Signatory desires together with means-end beliefs can ground
subjective practical reasons, or so I will
argue. 

## The Case of Donny ## { #sec:waltercase}

Donny wants to bowl a strike. Naturally, he
thinks  bowling is a  means to that end.  But
Donny's case is unusual. His reason for
wanting to bowl a strike is not that he thinks
it would be pleasant. In fact, he fully expects
bowling a strike would overwhelm
him with restless doubts. He expects he
would doubt whether the strike 
really happened or was some cruel hoax; he's sure
his resulting anxiety would keep him awake
all night. Donny is a 
nervous, fitful man; he trembles at great turns of
fate---especially when they involve money. 
What's Donny's deal? It's this: Donny's reason 
for wanting to bowl a strike is that he
believes an Amazing Predictor mailed him one
million dollars iff she predicted he'd bowl a
strike tonight. The money, he thinks,  will
arrive tomorrow if ever. So, on this night,
Donny  is cold to the usual appeal of bowling,
and doesn't think it'll be a means to anything
he desires besides the strike. He believes
bowling is a means to a strike, and his desire
for a strike  derives from his desire for
wealth in virtue of his belief that  a strike
would be a sign (not a cause) that he'll soon
be a millionaire. In particular, Donny
believes bowling is a means to a sign *that
will retain its significance as a sign* of the
million. In other words, Donny believes that
even if he "causally intervenes" in the
production of the sign, it will still be a sign
of the million. 
His desire to bowl a strike is signatory.

## My Two Main Arguments: Why Donny Has a Subjective Reason to Bowl Grounded in Signatory Desire ## { #sec:}

In this section I give two arguments for the claim that Donny has a subjective
reason to bowl grounded in his means-end belief and his desire to bowl a strike.
Some premises have been given specific titles in parentheses.

Here is my first argument: 

> [\uline{Argument 1}]{id="arg1"}

> Premise 1. [MEP](#mep) is true. 

> Premise 2. Donny believes that bowling is a means to bowling a strike. 

> Premise 3. Donny desires to bowl a strike. ("Desire to Bowl") 

> Conclusion 1. Donny has a subjective reason to bowl grounded in his means-end belief and his desire to bowl a strike. [From P1, P2, and P3]


How can this argument be resisted? An outright rejection of [MEP](#mep) would be
implausible and ad hoc. 
A more serious objection would seek to limit the application of
[MEP](#mep) to desires that aren't signatory. We'll consider such 
objections in [@Sec:objections].

Here's my second argument:

> [\uline{Argument 2}]{id="arg2"}

> Premise 4. Prior to making his decision Donny is  in a position be rationally moved to bowl by his means-end belief together with his desire to bowl a strike. ("In Position to be Rationally Moved") 

> Premise 5. [The Rational Movement Condition](#rmc) is true. 

> Conclusion 1. Donny has a subjective reason to bowl grounded in his means-end belief and his desire to bowl a strike. [From P4 and P5]

In support of In Position to be Rationally Moved, I would say that Donny is
intuitively in a position to bowl and   rationalize his  choice by saying, "I
want to bowl a strike tonight, and bowling is  a way to make that happen!"
Denying [The Rational Movement Condition](#rmc) outright just to avoid the conclusion
would, like a blanket rejection of MEP above, seem 
implausible and ad hoc. It seems therefore that the best way to resist this
argument is to give some reason for denying In Position to be Rationally Moved.
In [@Sec:objections] we'll look at attempts to motivate such a move.

Stepping back, what exactly does Conclusion 1 amount to?
Well, if  Conclusion 1 holds, Donny's signatory
desire to bowl a strike participates in two
distinct dependence relations. One is the
relation between Donny's subjective practical
reason to bowl and the pair consisting of his
desire to bowl a strike and his means-end
belief. The other is the relation between
Donny's desire to bowl a strike and his desire
for future wealth (a relation which holds in
virtue of his belief that bowling a strike
tonight is a sign---but not a cause---of an
impending million). Conclusion 1 is about the
first of these two relations. The second
relation is one that holds between desires in
virtue of connecting beliefs. It does not take
a subjective practical reason as a relatum.

## Supporting Argument: MEP Applies to Signatory Desires  ## { #sec:support}

In this section I defend [Argument 1](#arg1) with the following
arguments, which support the claim that
MEP applies to Donny's signatory desire to bowl a strike. 
Once again, some premises have been given specific
titles in parentheses.

> [\uline{Argument 3}]{id="arg3"}

> Premise 6. Unless Donny has some subjective practical reason to stay home and not bowl, Donny is rationally criticizable if he chooses not to bowl. ("Criticizable Choice") 

> Premise 7. [Act Criticizability](#ac) is true. 

> Conclusion 2. Donny has a subjective reason to bowl. [From P6 and P7]

> [\uline{Argument 4}]{id="arg4"}

> Premise 8. Donny is rationally criticizable if when deliberating over whether to bowl, he disregards his belief that bowling is a means to bowling a strike. ("Criticizable Deliberation")

> Premise 9. [Deliberation Criticizability](#dc) is true. 

> Conclusion 2. Donny has a subjective reason to bowl. [From P8 and P9]

> [\uline{Argument 5}]{id="arg5"}

> Premise 10. The best explanation for Donny's having a reason to bowl is that [MEP](#mep) applies to his signatory desire to bowl a strike. ("Best Explanation For Having a Reason to Bowl")

> Conclusion 3. [MEP](#mep) applies to Donny's signatory desire to bowl a strike. [From P10 and Conclusion 2]

How can these arguments be resisted? There are two main ways.
The first way to respond is to motivate a denial of 
Criticizable Choice and Criticizable Deliberation,
and then reject Best Explanation For Having a Reason to Bowl as 
falsely presupposing the existence of a subjective practical reason to 
bowl. The second way to respond is to accept Criticizable Choice
and Criticizable Deliberation and motivate a denial of 
Best Explanation For Having a Reason to Bowl 
by supplying a competing explanation for Donny's having a subjective 
reason to bowl. We'll look at both of these 
routes in [@Sec:objections].




## Summing Up ## { #sec:}

Those are my arguments  about Donny. I take
them to generalize. That is, I assume that
Donny's case points the way to all sorts of 
other possible cases with the same basic structure. Hence,
I take these arguments to show that  signatory
desires, together with associated means-end
beliefs, can ground subjective practical
reasons.

# Objections and Replies # { #sec:objections}


## Objection One: Refusing to Satisfy Signatory Desire is Uncriticizable ## { #sec:obj2}

This objection asserts that signatory desires are
such that refusing to try to satisfy them is rationally uncriticizable. It
directly targets Criticizable Choice and Criticizable 
Deliberation. A proponent of this would
reject Best Explanation for Having a Reason to Bowl 
as falsely presupposing that Donny has a reason to bowl; 
further, they would consider
[MEP](#mep) implausible if it is not
restricted to non-signatory desires.
This objection challenges [Argument 1](#arg1) 
by attacking my unrestricted use of MEP
and the support I offer for that in 
Arguments 3, 4, and 5. Notably, it does not
challenge [Argument 2](#arg2). So even if this
objection were successful, its proponents 
would have more work to do to rebut Conclusion 1.

### Reply: ### {.unnumbered #sec:}

If you want *p* to be true, and believe that
the only way you can cause *p* to be true is by
doing O, and you have no subjective practical
reason to do anything else, then if you choose
not to do O,  it's just obvious that you can be
rationally criticized.
"do not you want this? do not you believe that
the only way you can make it happen is to do O?
Instead, you've done something you have no
reason to do! What gives?"[^fn21] It is
inadequate to reply: "I do want *p* to be true,
but the only reason I want it to be true is
that I want *q* to be true and I believe that
the truth of *p* is a sign---but not a
cause---of the truth of *q*." This is
inadequate because the reason for 
wanting *p* to be true is  irrelevant.  We can
reply, "Yes, that is a perfectly reasonable
basis for wanting *p* to be true. What's
your point? Why aren't you doing the thing
you believe can cause *p* to be true, given
that you have no reason to do anything else?"
Perhaps they might protest, "It's the *type* of
basis the desire has. It does not derive from
another desire in virtue of a means-end belief,
but in virtue of a belief about  being a sign.
*That's* the excuse."   I reject
this invidious distinction. What is
disqualifying about the distinctive basis of a
signatory desire for *p*?  Does the agent  have
a reason for desiring *p*? Yes. Is the reason
a perfectly acceptable one? Yes. Is it granted,
therefore that the desire is not an irrational
one? Yes.[^fn22] I fail to see 
any excuse for not doing the thing they
think will cause *p*'s truth, given that they
have no reason to do anything else.

## Objection Two: Signatory Desires are Inherently Irrational ## { #sec:obj1}

According to this objection, signatory desires
are inherently irrational qua desires. Hence,
it's irrational to act with the aim of
satisfying them. In other words, according to
this objection, mere signs are always, as a
rule, irrational *to want*, and therefore it is
always, as a rule, irrational to act with the aim of 
satisfying desires for mere signs. Like the
previous objection, this objection challenges
MEP and a 
proponent of it would likely want to restrict [MEP](#mep) to
non-signatory desires. But unlike the last
objection, this objection also challenges
[Argument 2](#arg2) by targeting In Position to be Rationally Moved: it
is always irrational, according to 
this objection, to be moved  by a
signatory desire (together with a means-end
belief) since signatory desires are themselves
always irrational. Hence, contra In Position to be Rationally Moved,
Donny was never in a position to be rationally
moved by his signatory desire.[^fn23]

### Reply: ### { #sec:}

Recall Tom from
@Sec:evidential. Is there really something
inherently irrational about him wanting to receive a
"Yes" text? He seems in a position to give a
quite ordinary and reasonable account
of his desire. Receiving a
"Yes" text would be a sign 
that something he hopes to be the case is the
case: Judy is attracted to him.
What's irrational about this? 
Consider someone who doesn't want to get sick, and who
therefore desires to not feel a tickle in their
throat. Is it really
inherently irrational for them to want there to be no
tickle? Or consider wanting to see an "OPEN"
sign in the window of a restaurant you hope is
still open, or wanting to hear your doctor say
your newborn is healthy. Examples of what
seem plainly rational signatory desires can be
multiplied ad nauseam. The claim that such desires
are all inherently irrational must surely 
strike any unbiased judge
as being at odds with
common sense. 
At the very least, it is not the defender of 
the rationality of signatory desires who 
bears the burden of proof, since having and
explaining signatory desires is 
so commonplace. Let's consider, then, 
how my opponent might defend their doctrine.

Prevailing accounts of rational desire come
in four flavors. On *content-based* accounts, a desire is
rational iff it has the right sort of
content---e.g., it is a desire for the Good, or
for something believed good, or for something
there is objective reason to want [@AnscombeI;
@AudiAOR; @ParfitOWMV1]. On *deliberative*
accounts, desires are rational iff they are
produced, controlled, or sanctioned by an
actual or idealized process of rational
deliberation [@rawlstoj, pp. 407--424;
@BrandtTGR;  @smithmp, pp. 157--161]. On
*information-based* accounts, a desire is
rational iff it is not based on false beliefs
and/or it would be maintained even if the
desirer were suitably well-informed
[@HumeTreatise; @BrandtTGR;
@SavulescuRDALOLST]. On *coherence* accounts, a
desire is rational iff it suitably coheres with
the desirer's beliefs, desires, and/or
self-conception [@VellemanPR; @SmithRCBSM;
@SmithIDIR; @VerdejoNPD]. Let's look at each of
these in turn.

The sort of account that seems most apt
to deliver the result that signatory desires are all as a
rule irrational is a content-based account that
classes a desire as irrational if its
satisfaction is not, as a matter of fact,
objectively good for the agent. One might 
assert 

The Means to My Intrinsic Desire is My Good [(MIDIG):]{id="midig"}

: The objective good for an agent consists
in (α) the satisfaction of their intrinsic
desires and (β) any proposition whose truth
would cause the satisfaction of (one or more
of) their intrinsic desires. 

\noindent Next one might claim that since satisfaction of signatory
desires belongs to neither to (α) or (β), it is
never objectively good for an agent. Hence,
on this account of rational desire, such desires are as a rule
irrational. There are two problems with this.

The first problem is that MIDIG begs
the question. It is not obvious
that it is not objectively good for an agent to
get a sign they want, and more to the 
point it's hard to see why 
mere causes of intrinsic desire satisfaction 
should be part of an agent's good 
but mere signs of intrinsic desire satisfaction 
should not be. We could toss out 
condition (β), but then by parallel reasoning 
we wind up saying all extrinsic means-end
desires are inherently irrational. 

The second problem is that the sort of content-based account just
sketched seems promising as an account of when
there is objective reason for an agent
to desire something but doesn't seem
promising as an account of when 
there is subjective reason for an agent
to desire something. Recall
Bernie, who thinks his glass is full of gin and
tonic when in fact it's full of gasoline. Is
Bernie's desire to take a sip from his glass
rational? Here we seem to see the familiar
ambiguity. Bernie's desire seems unsupported by
objective reason but nevertheless subjectively
rational.  Since it is desires' subjective
rationality that would be relevant to whether
they can ground subjective reasons to act so as
to satisfy them, a content-based account seems
like the wrong sort of account to oppose the
rationality of signatory desires.


If content-based accounts do not support the claim that signatory desires are as a rule irrational, might some combination of the other three types of account do so? On the contrary, these accounts seem quite friendly to the rationality of such desires. It would be odd to deny that an informed and ideally reflective agent might desire a sign of something else they want, and that that desire might cohere  with the agent's beliefs and other desires.[^fn24]

Finally, it bears mentioning that even if
signatory desires were irrational, that on its
own would not trivially imply that seeking to
bring about their satisfaction would be
irrational. That inference is mediated by the
non-trivial assumption that it is as a rule
*practically* irrational to seek
to satisfy irrational *desires*.
But it is one thing for a desire to be
irrational, it is another for behavior aimed at
satisfying that desire to be irrational.
Personally, I'm for a sharp separation of
these two domains of rationality. An agent
whose actions are sanctioned by the beliefs
they have about how to best effect their
desires' satisfaction seems to me one whose
behavior makes rational sense, even if the
desires they aim to satisfy are
irrational.[^fn25]  Such a position seems in
keeping with a broadly Humean perspective on
rationality.[^fn26]

## Objection Three: Do You *Really* Want What You Extrinsically Want? ## { #sec:obj4}

This objection claims that when pressed we admit that we do not *really* want
the things that we only extrinsically want. Therefore,  extrinsic desires do not
exist [@MarksDBMD; @FinlayRTN]. For instance, if we press Donny by asking, "But
is bowling a strike *really *what you want?" it would be natural for him to
respond, "Well, no. All I *really* want is wealth." So perhaps Donny's desire
for a sign is not a real desire. If that's right, I was confused when I
stipulated Desire to Bowl (i.e., P3), 
and [Argument 1](#arg1) fails for the simple reason that
Donny doesn't want to bowl a strike---indeed he could not desire 
to bowl a strike unless he
intrinsically desired to bowl a strike. [Argument 2](#arg2) fails because
In Position to be Rationally Moved is false---Donny can't be 
in a position to be moved by a desire that is not even real.

### Reply: ### {.unnumbered #sec:}

It is undeniable that sometimes people say they want things only to 
admit under pressure they do not *really*
want them. But the fact that someone admits 
(or is disposed to admit) under pressure that 
they do not *really* want
something does not immediately imply that the 
desire doesn't exist, for as I will now
explain, the meaning of
questions like 'Is that *really* something you
want?' and 'What do you *really* want?'  is
context-sensitive. 

Asking what someone *really* wants, or whether something they profess to want is something they *really* want, can be interpreted in at least three ways depending on conversational context.[^fn27] First, it can be interpreted as asking whether a salient professed desire is a working desire. Second, it can be interpreted as asking what desire the salient professed desire proximally derives from. Third, it can be interpreted as asking whether the salient professed desire is intrinsic and/or what intrinsic desire the salient professed desire distally derives from. Thus,  in some contexts you *can* truthfully say you *really* want something that you merely extrinsically desire, and in contexts where you can't, the reason is that  the context  is such that 'what you *really* want' just denotes what you intrinsically desire. Let me elaborate.

Sometimes in the face of pressure we steadfastly affirm that we *really *want
things that we only extrinsically want. If we ask Donny whether he *really*
wants to bowl a strike tonight, he might reply, "Absolutely!" We might
continue, "But is not there some further thing you want that explains *why* you
want to bowl a strike tonight?" He might reply, "Of course, but that doesn't
mean I do not *really* want to!"  There's nothing unnatural about this. A
competent speaker would not judge his assertions to be baffling or
contradictory. It would seem that Donny is taking '*really* want' to denote
working desire as opposed to idle desire (@Sec:workingd), which is a perfectly
ordinary and acceptable interpretation. A real-world example might be helpful.
It's the day after the 2020 US Presidential Election. Votes are still being
counted in swing states like Michigan. I want Joe Biden to win the presidency.
If he's not going to win the presidency, I do not care if he wins Michigan. His
winning Michigan is desirable to me solely as a potential  means to his winning
the election---it is  an extrinsic desire. I am being sincere when I say I
*really*, genuinely want Biden to win Michigan. What do I mean? I take myself to
mean that my desire  is a working desire. I fantasize about Biden winning
Michigan. My attention is drawn to news alerts about Biden and Michigan. If I
learn that Biden wins Michigan I will be excited and pleased; if I learn that
he lost Michigan I will be displeased and troubled. And so on.

So we've just seen that there is one natural interpretation of '*really* want'
on which one can truthfully assert that one *really* wants something one only
extrinsically wants. For purposes of blocking the objection, this is all that's
needed. But for the sake of completeness, let's consider contexts where a
speaker accedes to not *really* wanting something they formerly professed to
want. Are all such contexts ones in which you cannot truthfully assert that you
*really* want what you only extrinsically want? I will argue
that the answer is No. Such contexts come in three varieties; let's look at them
one-by-one. 

In the first kind of context, the point of
asking whether someone *really* wants something
is to get them to confirm whether the desire is
a working desire. Suppose you ask, "Do you want
to hear Wolf Blitzer announce that Biden won
Michigan?" and I answer, "Yes." Then you ask,
"But is hearing *Wolf* make the call *really*
what you want?" I reply, "Well, no, I guess
not. What I *really* want is for Biden to win
Michigan. I do not really care who announces
it." In this example, my professed desire to
hear Wolf Blitzer announce a Biden win in
Michigan is idle. I believe that its
satisfaction would be a sign that Biden won in
Michigan, but I have no working desire to hear
Wolf Blitzer make the announcement---I do not
fantasize about Wolf in particular making the
announcement, etc.\footnote{Note the difference
between an idle desire for a sign, as in this
example, and a working desire for a sign, 
as in Donny and Tom's cases.} Note however that in this
case I've  truthfully said what I *really* want
is for Biden to win Michigan---but this, of
course, is an extrinsic desire.  

In the second kind of context, one asks whether someone *really* wants something they profess to want and what one is after is what desire their professed desire proximally derives from.    Suppose you ask, "But is Biden winning Michigan what you *really* what you want? What are you *ultimately* hoping for?" In this updated context it seems I can't truthfully reply by saying that what I *really* want is for Biden to win Michigan. Instead, I can say, "Well no, what I *really* want is a Biden presidency." If this satisfies you then it seems what you were after is  what desire my desire for a Biden win in Michigan proximally derives from. Note that I truthfully said that what I *really* want is a Biden presidency, which is still an extrinsic desire.

In the third kind of context, the point of
asking whether someone *really* desires
something is to get them to confirm whether
their desire is intrinsic and/or to say what
intrinsic desire stands at the end of the chain
of desires from which the professed desire
ultimately derives. Suppose you keep up your
pressure. Soon enough I'd catch on and might
say, "Well, I suppose what I *really* want is
for there to be happiness, health, peace, and
justice in human society." In the context
created by the repeat questioning it seems I
can't truthfully say I *really* want what I
only extrinsically want. But note that this
is not the most natural interpretation of
'*really* want'; it can take a bit of nudging
to fix on it. It can be hard to pin down one's
intrinsic desires. Pressing someone to do so
is liable to seem weird and demanding. Further, note that
in this sort of context 'what S *really* wants'
doesn't denote the set of all S's desires, or
even the set of all S's working desires---it
just denotes a set of S's intrinsic
desires.[^fn28] Saying you do not *really *want
something in such a context thus doesn't entail
lacking a working desire for it.

## Objection Four: Only Intrinsic Desires are Rationally Relevant ## { #sec:obj3}

The rough idea of this objection is that
intrinsic desires can do all the work we need
from desires in a theory of practical reason,
and therefore, extrinsic desires, including
signatory desires, do not ground subjective
reasons. This idea can take four 
forms, each targeting a different subset of my
premises. The four forms come in
two main variants each with two subvariants.
One main variant stays
neutral on whether extrinsic desires are real
psychological states and asserts that when it
comes to practical reason and rational
motivation such desires are explanatory third
wheels [cf. @MarksDBMD; @SmithIDIR]. This
variant attacks [MEP](#mep). On its first
subvariant, one claims that [MEP](#mep) needs to be restricted
to intrinsic desires---you'd go this route
only if you were prepared to deny Criticizable Choice 
and Criticizable Deliberation. On its second
subvariant, one says that a
restricted version of [MEP](#mep) is true
as a sufficient but not a 
necessary condition, and that a subjective
reason can also be grounded in a pair
consisting in an intrinsic desire and a belief
that an action would itself be a sign that
that intrinsic desire is satisfied---you'd go
this route if you wished to account for 
Criticizable Choice and Criticizable Deliberation without
appealing to signatory desire.
The other main
variant of the objection primarily targets 
Desire to Bowl and asserts that extrinsic desires
simply do not exist, i.e., Quines them\footnote{Here 
I'm using 'Quine' as a verb in the way 
popularized by Daniel Dennett.} [@ChanATED; @FinlayRTN].
This variant faces an analogous choice-point
dictated by whether Donny is
susceptible to rational criticism. On the one hand, 
the Quiner of extrinsic desires
might reject Donny's susceptibility
to rational criticism. If they go this route, 
there is no need for them to
also restrict MEP to intrinsic desires---that sort 
of move is called for
only if there might be an extrinsic desire 
that Donny takes bowling to be a means to,
and the Quiner says such desires 
do not exist. On the other hand, 
if the Quiner agrees 
Donny is susceptible to
criticism, then there has to be a subjective reason to bowl 
and [MEP](#mep) must be denied
as a necessary condition; it is again natural to deny
Best Explanation For Having a Reason to Bowl
and offer in its place the sort of
explanation mentioned above.
Regardless of which form this objection takes, it
will target Argument 2 via In Position to be Rationally Moved by claiming that only
intrinsic desires can
rationally move people. 

|  | Neutral on Extrinsic Desires | Extrinsic Desires do not Exist |
| :----- | :----- | :----- |
| Donny IS Susceptible to Rational Criticism | Denies Premises 1, 4, & 10. (Variant 1A)  | Denies Premises 1, 3, 4, & 10.  (Variant 2A)  |
| Donny is NOT Susceptible to Rational Criticism | Denies Premises 1, 4, 6, & 8.  (Variant 1B)  | Denies Premises 3, 4, 6, & 8.  (Variant 2B)  |

: Summary of the Four Variants of Objection Four {#tbl:obj-table}

### Reply: ### {.unnumbered #sec:}

Let's start with those who accept my claims
about Donny's susceptibility to rational
criticism but reject [MEP](#mep) as a necessary 
condition and deny Best Explanation For Having 
a Reason to Bowl.[^fn29] Someone going this route
will need to explain Donny's susceptibility to
rational criticism, and the most natural way to
do so is to appeal to Donny's intrinsic desire
for wealth together with the fact that he
believes the act of bowling would itself be a
sign of impending wealth. Thus, it
seems, someone going this route will accept

Evidential Sufficient Condition [(ESC):]{id="esc"}

: If an agent S has a desire D for *p* and a belief B that one of their options O is a sign (but not a cause) of the truth of *p*, then the agent has a subjective practical reason, grounded in B and D, to do O. 

Here I think we're encountering an intuitive
fault line. All I can say is that to my mind it is 
primitive that insofar as rational action
relates to desire, its aim is to do the most
one thinks one can to *make* the world *into*
what one wants it to be. If you believe an
action would be a mere sign of that some desire
of yours is satisfied, but would do nothing to
*affect* whether that desire is satisfied, then
that desire doesn't ground any subjective
reason to do that action. James Joyce
puts the idea nicely when he writes, 

>[R]ational decision makers should choose actions on the basis of their *efficacy in bringing about desirable results* rather than their auspiciousness as harbingers of these results. Efficacy and auspiciousness often go together, of course, since most actions get to be good or bad news only by causally promoting good or bad things. In cases where causing and indicating come apart, however, ... it is the causal properties of the act, rather than its purely evidential features, that should serve as the guide to rational conduct. [@joyce99, 150]

Is this a distinction without 
a difference? Is denying [ESC](#esc) while
maintaining that [MEP](#mep) applies to
signatory desires in some sense not
meaningfully different from denying [MEP](#mep)
as a necessary condition, accepting [MEP](#mep)
as a sufficient condition, and maintaining
[ESC](#esc)? I will argue No.

The claim that my rejection of ESC amounts
to a superficial distinction has 
force only if the following principle
is a necessary truth: 

Signatory Belief to Desire [(SBD):]{id="sbd"}

: An agent with option O desires to do O if their beliefs entail that doing O would be a sign (but not a cause) of the satisfaction of one of their desires. 

\noindent If [SBD](#sbd) is a necessary truth, then
necessarily, if an agent S is minimally rational,
[ESC](#esc) implies S has a subjective reason to do φ
only if [MEP](#mep) also implies S has a
subjective reason to do φ.[^fn30]  But
[SBD](#sbd) is not a necessary truth. 
There could be a hard-nosed sort of person, 
a "stoic causalist,"
who one day lacks any desire 
to do a thing they're certain
is not a means to anything they want,
despite believing that to do it would be
a sign of something they want. 

Should we take [SBD](#sbd) to be a norm,
and hence conclude that the only time 
[ESC](#esc) and [MEP](#mep) 
clash is in cases where the agent is "already"
irrational? I do not think so. For one thing,
[SBD](#sbd) only supports the connection
between [ESC](#esc) and [MEP](#mep) if it is
restricted to working desire. But given that
restriction, [SBD](#sbd) should strike us as 
a pretty unintuitive norm. (Would the stoic causalist 
be criticizable for, e.g., feeling no "pull" to
doing the thing that would have no 
causal impact on what they care about?) 
For another, even if  [SBD](#sbd) were
a norm, violating it would  make one guilty of
*conative*, not practical, irrationality. The
violation would entirely consist in lacking a rationally
required desire [cf. @AudiAOR, p. 69]. It is
not obvious that an agent couldn't be
conatively irrational in such a way while still being
practically rational and vice versa; these seem
to be separate normative domains  (cf.
@Sec:obj1). While the broader issue 
deserves more examination, I am confident 
that the disagreement between
[ESC](#esc) and [MEP](#mep) over what
subjective *practical* reasons are had by the stoic 
causalist  (who, ex hypothesi, would be
conatively irrational) is substantive
regardless of whether SBD is a norm.

So much for the rejection of Best Explanation 
For Having a Reason to Bowl by way
of [ESC](#esc) and [SBD](#sbd). If that route
is a dead end to any believer in MEP
as a necessary condition, where does
that leave this objection? It seems the only
available alternative is to deny Criticizable Choice
and Criticizable Deliberation and claim Donny is not susceptible to
rational criticism in the ways I suggest in
@Sec:support. There are two possible routes.
One route is to remain neutral on the existence
of extrinsic desires and claim that it is 
rationally uncriticizable to not do what
you think would satisfy such desires,
provided you do not think the rejected action 
might also lead to the
satisfaction of any intrinsic desire.[^fn31]
I've already presented my case for the
untenability of this route in @Sec:obj2 and
@Sec:obj1.\footnote{The former section 
responds directly to the idea that Donny is 
rationally uncriticizable if he chooses not
to bowl. The latter section bears indirectly
on the same issue, insofar as it argues against one 
possible basis for claiming a refusal to bowl
would be uncriticizable, namely that signatory
desires are inherently irrational. As indicated
in that section I personally think that such an 
argument would be moot, since I think we must
strongly separate conative from practical 
irrationality, but I realize not everyone will
agree on that score.} Setting that route aside leaves the
final route that this objection might take. One
might argue that extrinsic desires simply do not
exist; and no one can be rationally criticized
for failing to aim to satisfy desires that just
aren't there.[^fn32] This route denies 
Desire to Bowl, In Position to be Rationally Moved,
Criticizable Choice, and Criticizable Deliberation; 
it dismisses Best Explanation For Having a Reason to Bowl as having a
false presupposition (i.e., the presupposition 
that Donny indeed has a subjective practival
reason to bowl). I assume it accepts 
MEP and does not restrict it (since it denies 
any need for a restriction---extrinsic desires
do not exist). I've already considered
and rejected an argument that could be used to support 
this position in @Sec:obj4. Let's consider a
different sort of argument.

The sort of argument we 
turn to now uses
inference to the best explanation (IBE). 
Examples in print focus on motivation. They claim that since
rational motivation can be accounted for by
intention and intrinsic desire [@ChanATED] or
by belief and intrinsic desire [@FinlayRTN;
@FinlayMTM] there is no reason to 
posit extrinsic desires.
Taking this IBE route to denying the existence 
of extrinsic desires puts my opponent in a
somewhat awkward position, as there appear 
to be in Donny's case
two things intrinsic desire is ill-suited to 
explain: (1) Donny's meriting blame if he doesn't bowl (and
praise if he bowls), and (2) Donny's being in a 
position to be motivated to bowl. 
Additionally, aside from cases like Donny's, I think 
extrinsic desires play the causal roles 
characteristic of desire (@Sec:droles) 
in many cases better than intrinsic desires---this too 
presents a serious difficulty for an 
IBE-based rejection of extrinsic desires.


Let's start with Donny's susceptibility to
criticism. The opponent we're now considering
thinks there is no such susceptibility. But why
not? Well, one kind of inference to the best
explanation takes a liberal stance with regard
to explananda. It is happy to deny certain
would-be explananda if doing so results in a 
overall pattern of data with a parsimonious and 
unifying explanation. So the Quiner of
extrinsic desire might argue that we should 
just reject Criticizable Choice and 
Criticizable Deliberation since in so
doing we get rid of a few stray explananda
that aren't readily captured via intrinsic
desire.\footnote{Alternatively, the Quiner could
endorse ESC and say that intrinsic desire 
captures these explananda via that principle.
I've already given my response to that route. 
The Quiner we focus on now agrees that ESC is a no-go.}
The result of rejecting the intuition that Donny
merits criticism if he refuses to bowl, goes the thought,
is a simpler, more elegant, less
gerrymandered combo of explananda 
and explanans. This take seems to
me born out of too severe a lust for parsimony.
The existence of extrinsic desires does not seem
inelegant or gerrymandered. To be
sure, a theory that posits only intrinsic
desires is just plain *simpler*, but brute
simplicity is a slim basis for rejecting the
intuitions regarding Donny's
susceptibility to criticism. The tradeoff
appears less like good abduction and more like
fetishism.
But aside from this, 
there is a firmer reason
to resist the Quiner: there
are additional explananda, apart from Donny's
susceptibility to criticism, that intrinsic
desires alone are ill-suited to handle.


Consider motivation. Even if, to
avoid begging the question against this
objection, we do not assume Donny is in a
position to be moved to go bowling by a
signatory desire to bowl a strike, surely it
must be granted that he is *somehow* in a
position to be moved to go bowling. The battle
should be over what the best explanation for
this potential motivation is. My opponent will
claim the best explanation involves Donny's
intrinsic desire for wealth, rather than any
signatory desire to bowl a strike. Given that
Donny does not believe bowling is a means to
satisfy any intrinsic desire, how can his
intrinsic desires get involved in his
motivation to bowl? The reply is that Donny can
be motivated by the complex of his intrinsic
desire for wealth and his belief that bowling,
specifically bowling a strike, would be a
sign of the satisfaction of that
desire.[^fn34] On this picture, Donny
can be moved to bowl despite not thereby being
moved to acquire, make manifest, realize, or in
short, to cause, something he wants, to take
place.[^fn35] This does not square with the
sort of explanation we would most naturally
expect Donny to give for why he chose to bowl,
should he so choose, or why he was tempted to
bowl, should he not. Our natural expectation
would be that he would explain his motivation
in terms of a desire to bowl a strike: he is
thinking about that strike and what it would
mean, and he wants it to happen. It is
less natural to suggest that on the contrary,
he doesn't want the strike to happen, and
indeed doesn't think bowling would yield
anything he wants, but that he believes it would be
a sign of something he wants, and can be moved
by *that alone*.[^fn37] Indeed I would go as
far as to say that the very idea of such
motivation, in which there is no prospect of
getting anything one wants,[^fn38] is
incoherent.\footnote{\emph{Interlocutor:}
Donny believes he will get evidence about something he
wants. is not it coherent that that 
could be enough to move him? \emph{Reply:} My
claim is precisely that he wants that
evidence, and that that desire can move him;
by contrast, my opponent says he does not want the
evidence and yet is somehow moved by it.} Stepping back,
though, it is unnecessary
to press this incoherence claim; to rebut the
IBE-based argument it suffices
to point out that the explanatory
picture the Quiner offers is less natural than that
Donny's motivation would come from a common
means-end belief and his desire to bowl a
strike.

 There is one final set of data that intrinsic desires are ill-suited to help
 explain, and for which it seems extrinsic desires ought to be posited. Namely,
 it seems clear that extrinsic desires, including signatory desires like
 Donny's, are in some cases the most natural states to play the causal roles of
 desire (cf. @Sec:droles). That is, extrinsic desires, it seems, can be working
 desires (cf. @Sec:workingd). I've already discussed this in @Sec:obj4. 

Not everyone agrees. Notably, @ChanATED presents several cases meant to show that only intrinsic desires can play the causal roles stereotypical of desire.  Here is one of his cases: 

> John may be afraid of dogs and dislike the sight of dogs. But John may be in love with a woman whom he regularly sees walking her dog around the block. John may therefore welcome, and even look forward to, seeing her dog coming around the corner on its leash, as he knows that it will be followed by his beloved coming into view. Since John does not have an intrinsic desire to see the dog, it is suggested that his positive feelings in favor of seeing the dog can be attributed to an extrinsic desire.

Speaking of this case, Chan says the following: 

> It is not the sight of the dog but the thought of seeing his beloved that gives John pleasure, and he would be not in the least disap­pointed if his beloved appeared around the corner without her dog. The daydreaming that is motivated by John's desires will be about meeting his beloved without the dog appearing, even if this cannot happen in the real world. 

Chan's claims  strike me as unappealing. I see
no reason why imagining or experiencing the
sight of the dog rounding the corner cannot be
a source of pleasure for John. ("Oh boy,
there's her dog! In just a moment, she'll be
rounding the corner as well!") To be sure,
John's belief that the dog is a sign  of the
woman's impending presence is (ceteris paribus)
a necessary  background condition for the
causation of pleasure by dog sighting (imagined
or real). But nevertheless, the sight itself
still intuitively can cause pleasure. By the
same token, it is implausible to insist that
John cannot daydream about the dog's appearing
(only to be followed closely by his crush)
absent an intrinsic desire to see the dog. Here
my opponent might argue that all that's needed to
explain John's pleasure at the dog sighting
(imagined or real) is an intrinsic desire to
see his crush together with a belief that the
dog is a sign that he'll soon see
his crush. They might say the same thing about
the other causal effects of the supposed extrinsic 
desire, e.g., John's
attention being directed toward the sound
of a dog approaching, and the "pull" he feels
toward the thought of seeing the dog. This
seems to me best taken as an
argument for the view, defended by @SmithIDIR,
that extrinsic desires can be reduced to
"suitably related" complexes of intrinsic desire
and belief.[^fn40]  It seems to give us no
reason to eliminate John's extrinsic desire
altogether. Whether Smith's reduction succeeds
or not, extrinsic desire is in no danger of
elimination.

The reader might be unsure of my take on Chan's case. Reasonably so. The sort of intuitions I'm aiming to prompt  are liable to be muddied  due to the "closeness," causally and spatiotemporally, of the objects of John's extrinsic and intrinsic desire (i.e., the dog and John's crush). I suggest we consider a case that lacks this closeness. 

Recall my Biden example from @Sec:obj4.
Consider me in the days after
the 2020 election, before Biden's victory was
announced. For me in that state, to find out that 
Biden has won Michigan would be a
source of great pleasure; I fantasize about a
Biden win in Michigan; my attention is drawn to
news alerts about Michigan; etc. Some desire
ought to be playing these roles. My claim is
that it is an extrinsic desire for a Biden win
in Michigan. But notice: all the ready-to-hand
alternative desires that might play those roles
are *also* extrinsic. What are those desires?
Well, a desire for a Biden presidency, for a
reversal of Trump's policies on climate change,
for more humane policies on immigration, etc.
Assuming these desires exist, none of them are
for things  I want *in themselves*, and in fact
I'm not even sure exactly what intrinsic
desires of mine would ultimately support them.
If forced to specify the intrinsic desires,
they'd be something like desires for general
human happiness, equality, health,
flourishing---but those too might ultimately
turn out to be extrinsic desires. My immediate
answer would be nebulous and tentative and I
would need to reflect on it to sort it
out.[^fn41]  In this case, it is, I expect,
clearer than in Chan's case both that an
extrinsic desire---my desire for a Biden win in
Michigan---is playing the desire roles, and
that there are no clear intrinsic desires
ready-to-hand to usurp those roles.

# The Two-Level Account # { #sec:tla}

I have argued 
that an extrinsic (i.e., signatory) desire together
with a means-end belief can ground a subjective
practical reason. 
The cases I used demonstrate further that such reasons
can occur even if the agent is certain none of 
their options are means to 
any intrinsic desire.
So, there can be a subjective reason to do φ
grounded solely in extrinsic desire, 
unaccompanied by any concurrent reason to do φ
grounded in intrinsic desire.
What is the status of such reasons? 
In particular, what happens when they compete
with reasons grounded in intrinsic desire?
In this section I defend 
the view that subjective
reasons grounded in signatory desires
can be *trumped* by reasons grounded in 
intrinsic desire, and that this can happen 
even when the desires 
and beliefs grounding the respective reasons are
of equal respective intensities.

Suppose you only have two options, A and B.
You believe A is a means to satisfy an
extrinsic desire but not any
intrinsic desire, and  B is a means to satisfy
an intrinsic desire. Suppose the desires are of
equal intensity and the beliefs carry
equal confidence. You
rationally must do B. Why? Not because of any
*quantitative* difference between your desires 
or reasons, rather because of the *qualitative* 
difference between intrinsic and
extrinsic desires. If you intrinsically desire
something, you want it for its own sake---it is one of 
your basic ends. If you only extrinsically desire
something, you do not want it for its own
sake---it is not one of your basic ends. It is
irrational to pursue something that is not one
of your basic ends at the expense of  something
that is---or at  least this is so when the
desires for the two things are of close to
equal intensity and your levels of confidence
in your ability to obtain each are close to
equal.

Let's check this with a case.  Walter believes
a Predictor whose predictions he's sure are 
roughly 90% reliable sent
him a coupon for a club sandwich, a beer, and a dessert 
iff she predicted he would not bowl
today. He believes the coupon will arrive
tonight, at his house, if ever. What Walter
intrinsically desires are pleasurable taste
sensations (measured in gustatory hedons). He
doesn't believe staying home is a 
means to such sensations, since the coupon 
is either already in the mail or it is not 
coming regardless. His other notable option is to 
go bowl with Donny and The Dude. 
He's confident that if (and only if) he hangs out 
with them, they'll buy him a
club sandwich and a beer. A club sandwich
and a beer would yield 9 gustatory hedons; 
an added dessert would make it 10.
So, Walter does not believe staying home will get him 
any gustatory hedons, but it will get him a 
*sign* (with roughly 90% reliability) that 
he is going to get 10 hedons. 
By contrast, he's more or less certain that hanging out 
with his friends will procure him 9 gustatory 
hedons. His desire for the 
sign of 10 hedons and his desire for 
9 hedons are
of close to equal intensity, but they are of
different quality: one is extrinsic, the other
intrinsic. 
His confidence in the claim that the 
Predictor is 90% reliable is roughly equal 
to his confidence in his friends' willingness
to buy him dinner. 
There are no other desires Walter
believes might be satisfied as a result of
anything he can do tonight. He can't both stay 
home and go bowl; he must choose one.

By [MEP](#mep), Walter has a subjective
practical reason to stay home, grounded in his
signatory desire together with the
associated means-end belief, and a subjective
practical reason to go hang out with his friends, grounded in
his intrinsic desire for nine gustatory hedons
together with the associated means-end belief.
What I claim is that  the reason grounded in
the signatory desire is trumped by the reason
grounded in the intrinsic desire, even if the
two desires have equal intensity.  In other
words, Walter is not faced with a toss-up; the
only rational option is to see his friends. To
reiterate the core intuition, there is an inherent
irrationality in choosing to make desirable
signs of your ends happen rather than make your
ends happen---or this is so at least in a case
like Walter's, where the desire for the sign
and the intrinsic desire are close to equal in
intensity and the respective means-end beliefs carry close
to equal confidence. It 
bears emphasizing that trumping in cases like
Walter's is not due to one reason's arising from
a  means-end  belief and the other's arising
from a "signatory belief"---both arise from
means-end beliefs.

Are there any cases where trumping 
does *not* occur? If the extrinsic
desire is far more intense than the intrinsic
desire or the agent is far more confident
in their ability to satisfy the extrinsic
desire should we say that the reason grounded
in the intrinsic desire still trumps the reason
grounded in the extrinsic desire? In short,
are there *thresholds* that prevent trumping?
Intuitions may diverge.
In the interest of setting forth
the securest aspects of an account of
subjective reasons
grounded in signatory desire, I will 
take a neutral approach. I will incorporate
thresholds into my account, but 
make no assumptions as to where
these thresholds should be set, or even whether they should
be finite rather than infinite. So long as
trumping occurs in cases like Walter's, where
thresholds clearly do not come into play---given
the near equality in both (a) the intensities of
the signatory and the intrinsic desire and (b) the levels of
confidence in the respective means-end beliefs---the outlines
of a view involving trumping can be drawn.

Let's say that a subjective
practical reason grounded in an extrinsic
desire is *subordinate*, and a subjective
practical reason grounded in an intrinsic
desire is *superior*. Let the *weight* of a
subjective practical reason grounded in a
means-end belief and a desire be a
non-decreasing function of the confidence the
belief carries and the desire's
intensity.[^cf2] For any given option O, I
assume there is some (possibly empty)
set[^fn44] containing all and only superior
(/subordinate) reasons that favor O; I call this
set *the* set of superior (/subordinate) reasons
favoring O, and I assume the reasons in that
set have a total weight which is a function of
their individual weights.[^fn45] I say that an
agent's  superior reasons favor some option O
iff there is no O* such that the total weight
of superior reasons favoring O* is greater than
the total weight of superior reasons favoring
O. Let every positive number be a *threshold*.
Say that the set of subordinate practical
reasons to do an option O is *trumped* if its
total weight is below the appropriate
threshold, and the superior subjective
practical reasons favor some alternative
option(s) distinct from O.\footnote{Note that 
this is only a sufficient condition. There may 
be other circumstances in which a subordinate
reason is trumped; I am currently uncertain 
about this.}$^{,}$[^fn46]  Say the set
of subordinate reasons to do an option is
*active* iff it is not trumped.

With these definitions in hand, I propose 

The Two-Level Account [(TLA):]{id="tla"}

: If the set of subordinate subjective practical reasons $\mathbb{R}$ favoring an option O is active, its member(s) play the distinctive roles of  subjective practical reasons. If $\mathbb{R}$ is trumped,  

1. The member(s) of $\mathbb{R}$ do not contribute their weight to O; the weight, individually and collectively, of the member(s) of $\mathbb{R}$, is irrelevant to what it is  rational for the agent to do. 

2.  The agent may not be rationally criticized for  failing to act in accord with $\mathbb{R}$. 

3. If the agent has suitably involved all their superior subjective practical reasons in their deliberation,  failure to also consider, individually or collectively, the member(s) of $\mathbb{R}$,  is not  rationally criticizable.[^fn47] 

4. The agent cannot be rationally motivated by $\mathbb{R}$.[^fn48]

[TLA](#tla) and [MEP](#mep) are logically independent.
One could accept MEP only as 
a sufficient condition while also accepting 
ESC (cf. @Sec:obj3) and 
consistently conjoin both of those
with TLA. Since I accept MEP as 
a necessary and sufficient
condition and reject ESC, I prefer to take MEP and TLA 
as a package view, on which you can 
only have a superior subjective reason to do
some option O if you believe that O is a means
to the satisfaction of an intrinsic desire.  I
call the conjunction of [TLA](#tla) with
[MEP](#mep) the *Two-level Means-end Account*.


Given the Two-level Means-end Account, Walter subjectively rationally ought to
hang out with his friends. By [MEP](#mep), Walter has a superior  reason to hang out,
and a subordinate reason to stay home. The
latter reason is trumped (viz., its weight is below the appropriate threshold
and Walter's superior reasons favor a different option). So, by [TLA](#tla),
Walter's subjective reason to stay home does not contribute its weight. Since  his
only other subjective reason favors hanging out with his friends, that's the rational
choice.

There can be interesting cases where the subordinate reasons for one option are
trumped but those for another option aren't. One way this can occur is if the weight
of the former but not the latter is below the appropriate threshold. 
But it can also occur if superior reasons do not favor a unique option. 
Suppose there are subordinate reasons R1 to do A and R2 to do B, where R1 and
R2 have weights below the threshold (so they are both "trumpable"), 
and superior reasons
favor doing either B or C. In this case, R1 is trumped, but R2 is not. 
Let's look at a case that illustrates this. 

The Dude intrinsically desires  pleasure. He's
certain that a Predictor mailed him a free day-pass to a spa iff she
predicted he would bowl at Alley A, and eight dollars iff she predicted he
would bowl at Alley B. The Dude wants to bowl at Alley A (/B), since he believes
that would be a sign of an incoming spa pass (/eight bucks).  The Dude thinks a
spa day would be ten hedons; as for the eight bucks, he can use it 
to buy a White Russian, good for one hedon. Now, unlike Alley A, to which he's indifferent,
The Dude likes Alley B; he digs the ambiance. 
He's certain going to Alley B is a means to nine hedons. 
If he stays home, Dude will 
take a long bath, also nine hedons. Like Walter, The Dude takes
the Predictor to be 90% reliable. See @Tbl:dude-table below for a summary of The
Dude's hedons in each action-prediction combination. 

For simplicity and definiteness, let's assume that the weight of a reason grounded in a 
desire D and a belief B is equal to the strength of the desire times the 
confidence (understood as a percentage) carried by the belief. Let's also assume
that The Dude's desire for n hedons has an intensity of n.\footnote{These
assumptions could be relaxed to make the case more realistic but they're fine
for purposes of this illustration.}
The Dude has no superior reason to bowl at Alley A. He has a subordinate reason
to bowl at Alley A with weight 9 = (desire for 10 hedon spa pass) $\times$ (90% confidence 
that bowling at Alley A is a sign of the spa pass). He has a subordinate
reason to bowl at Alley B with weight 0.9 = (desire for 1 hedon white russian) $\times$ (90%
confidence that bowling at Alley B is a sign of eight bucks, enough for 
one white russian). He has a superior reason to bowl at Alley B with 
weight 9 = (desire for 9 hedon experience at Alley B) $\times$ (100% confidence
that bowling at Alley B is a means to 9 hedons). Lastly, he has a 
superior reason to stay home with weight 9 = (desire for 9 hedon bath soak) $\times$ (100%
confidence that staying home is a means to 9 hedons).

Should Dude bowl at Alley A and get that
sign of the spa pass? Or is he permitted to 
either bowl at Alley B or stay home, since either
one is a means to more intrinsically desired 
pleasure than bowling at 
Alley A is a means to? None of the above!
Given its equality in weight to the superior reason to bowl at Alley B, the
Dude's subordinate reason to bowl at Alley A is trumped. But the subordinate reason to
bowl at Alley B is active and breaks the tie with staying home. The Dude
should bowl at Alley B: it's a means to just as much intrinsic desire
as soaking in the tub, but it also satisfies 
a signatory desire.[^edtfn]

[^edtfn]:If we assume agents' utility functions over possible
worlds ignore extrinsic desires and reflect intrinsic 
desire only (cf. Weirich [-@weirichDS; -@WeirichIUC; -@weirichMODM]), we can observe
an interesting decision theoretic result. Evidential Decision Theory 
says The Dude must bowl at
    either Alley A or Alley B, since according to EDT,
$\text{ExpectedUtility}(\text{AlleyA})=\sum_{n}n[\text{Pr}(n~\text{hedons}|\text{AlleyA})]\approx
10=\text{ExpectedUtility}(\text{AlleyB})=\sum_{n}n[\text{Pr}(n~\text{hedons}|\text{AlleyB)}]\approx
10>\text{ExpectedUtility}(\text{Home})=\sum_{n}n[\text{Pr}(n~\text{hedons}|\text{Home)}]\approx
9$. By contrast, Causal Decision Theory says he can either bowl at
Alley B or stay home, since according to CDT,
$\text{ExpectedUtility}(\text{AlleyA})+9\leq
\text{ExpectedUtility}(\text{AlleyB})=\text{ExpectedUtility}(\text{Home})$. 
Hence, by the lights of the Two-level Means-end Account, both 
Evidential and Causal Decision Theory are wrong, for The Dude must bowl at Alley B!
For background on decision theory and the debate between the Evidential and 
Causal theories, see @jeffreyLD, @nozick69, @gibbardharperCTKEU, Sobel
[-@SobelPCC; -@SobelNODT], Skyrms [-@SkyrmsCN; -@SkyrmsPE], @LewisCDT, and
@joyce99.

|  | A Predicted | B Predicted | Stay Home Predicted |
| :----- | :----- | :----- | :----- |
| Bowl at A | 10 | 1 | 0 |
| Bowl at B | 18 | 10 | 9 |
| Stay Home | 18 | 10 | 9 |

: The Dude's Hedons Depending on Which Prediction Was Made and What He Does {#tbl:dude-table}

|  | Bowl at A | Bowl at B | Stay Home |
| :----- | :----- | :----- | :----- |
| Total Weight of Superior Reasons |  | 9 | 9 |
| Total Weight of Subordinate Reasons | 9 | 0.9 |  |

: Summary of Weights of Reasons {#tbl:dude-table2}

# Conclusion # { #sec:}

Normally, when you want a sign, 
you do not also believe you can make that sign
happen without undermining its significance, but 
as illustrated by cases like Donny's, 
Walter's, and The Dude's, such cases are 
indeed conceivable. I've argued that in 
these cases, the agent has a
subjective reason to bring about the sign they desire, and that this reason can
be accounted for by the straightforward means-end principle MEP. The view that subjective
reasons can be grounded in desires for signs implies that they can be grounded
in extrinsic desires; I therefore responded to philosophers who have argued that
extrinsic desires aren't rationally relevant as well as those who have argued they
simply do not exist.  In the fourth section, 
I argued that the reasons grounded in extrinsic
desires can be trumped by reasons grounded in intrinsic desires, and presented
my Two-level Account to codify this idea. Conjoining this account with the
aforementioned means-end principle yields an attractive outline of
a theory of desire-based subjective reasons, the Two-level Means-end Account. 

[^fn1]: Henceforth, I will often leave 'practical' in 'subjective practical
    reason' tacit.

[^fn2]: I intend 'grounded in' as a placeholder for the distinctive relation between subjective reasons and belief-desire complexes. This relation could be like the 'in virtue of' relation familiar from the literature on metaphysical grounding, or it could be like constitution or identity.  
	
	I intend 'is a means' in a broadly causal sense. In particular, the fact that *p* is/will be true if O is done is not sufficient for doing O to be a means to the truth of *p*. It is sufficient (but not necessary) for doing O to be a means to the truth of *p* in the intended sense that doing O will/would cause *p* to be true.  It is natural, for instance, to say that my drinking coffee is a means to staying alert. This ordinary, broadly causal sense of 'is a means' anchors my usage.  Two  notable ways for S doing O to be a means to the truth of *p* in the intended sense: (1) S doing O would increase the objective chance of *p*, (2) *p* is the proposition that S does O. 
	
	
	
	Readers may find MEP more plausible if, on the right-hand-side of the biconditional, instead of 'belief', we write 'justified belief' [@JoyceMOM; @GerkenWAA], or 'justified true belief' [@LittlejohnMWAOOWWK], or even 'piece of knowledge' [@HawthorneStanleyKAA]. If so, they should read as if this substitution has been  made  throughout, and as if the same modification has been made in the right hand side of [The Rational Movement Condition](#rmc) below. Notably, readers who opt for either of the latter two substitutions will have to say Bernie does not have a reason to take a sip grounded in his means-end belief and desire for gin and tonic; they will require a different sort of case to illustrate the subjective/objective reasons distinction.


[^fn3]: MEP can be fairly considered an internalist-adjacent principle [cf. @williams_internal_1979; @smithmp]. But care should be taken in drawing this connection. Internalism about practical reason is sometimes understood as the view, roughly, that an agent S has an objective practical reason to do φ iff S would be motivated to do φ if S were fully informed and deliberating perfectly. Since MEP concerns subjective rather than objective practical reasons, the falsity of Internalism as just stated does not imply (or at least, does not trivially imply) the falsity of MEP. 
	
	
	
	MEP can be fairly considered a  Humean-adjacent principle as well  [cf. @JoyceMOM, 52-53]. But similar care should be taken here. Humeanism about practical reason is sometimes understood as the view that, roughly, an agent's objective practical reasons are as a rule grounded in their desires [@SchroederSLOP]. The falsity of Humeanism in this sense does not imply (at least, not trivially) the falsity of MEP. 
	
	
	Here's the reason for the "at least not trivially" parentheticals. Some theorists characterize subjective reasons in terms of objective reasons. For instance, @LordHRAFA defends the Factoring Account  (cf. @SchroederHR), on which  subjective reasons are just objective reasons that one in some sense "has." A less reductive view, favored by  @SchroederSLOP and @ParfitOWMV1, says roughly that one has a subjective reason to do φ just in case one has a belief that if true would give one an objective reason to do φ. Other such "objectivist" theories have been proposed  [@VogelsteinSR; @WhitingKTIP; @SylvanWARATB; @WodakCOAFSR; @WodakAOGTSR]. If such a theory is true---a  question on which I take no stand---then Internalist and Humean theories of objective reasons may turn out to entail [MEP](#mep).

[^fn4]: There might be some subjective reasons that it is suitable to ignore when deliberating [cf.  @wedgwood2013].

[^fn5]: [The Rational Movement Condition](#rmc) coheres with a plausible account of motivating reasons provided by Mark Schroeder [-@SchroederSLOP], which states that for R to be an agent's motivating reason for doing some act A is just for R to be both a subjective reason for her to do A and  an explanatory reason for why she did A.


[^fn7]: Intrinsic desire is often contrasted with instrumental desire, i.e., desire for something as a means to some  end. But as the category of signatory desire illustrates,  not all extrinsic desires are instrumental [@HarmanEV, 128-9; @McDanielBradleyDesires; @ArpalySchoederIPOD].

[^fn8]: @McDanielBradleyDesires leave out the parenthetical bit. 

[^fn9]: Note that it only makes sense to reflect on "what it is about" the object of a desire that is desired if the desire is extrinsic. An intrinsic desire's object is desired in itself!

[^fn10]: Vaquitas are a rare and endangered species of porpoise. Knafeh is a type of cheesy Arabian cake.

[^fn11]: Or rather, play "enough" of them [cf. @Braddon-MitchellNolaICP, §1].

[^fn12]: The distinction between idle and working extrinsic desires is what I appeal to in reply to a worry with [MEP](#mep) based on a 
proliferation of subjective practical reasons grounded in extrinsic desires with 
gerrymandered contents (e.g., my "desire" for a million dollars cash buried under a foot of cat litter). Such desires are idle.

[^fn13]: ...or evidence or justified belief (etc.). I focus on knowledge but the points generalize as far as I can tell. Thanks to an anonymous referee for raising this issue.

[^fn14]: All the "Amazing Predictors" in this paper are, unless stated
    otherwise, known by the agents in the cases to be almost but not quite
infallible predictors of future events.

[^fn15]: Here one might ask: would not it be
    natural for Patrick to both want and not
want to know? My response: I but I think
my intended way of imagining him is also
available.

[^fn16]: Maybe Terry believes himself to not be the sort of person to behave any differently given such knowledge, or perhaps Terry is a very old recluse who does not foresee any future loving relationships, regardless.

[^fn17]: Suppose you want to know whether Stop and Shop is open midnight on
    Saturdays.  It is natural to think  this desire derives from further
desire(s) by virtue of belief that the knowledge is a means to getting
groceries. 

[^fn18]: The question is like asking "Why do you want that means to your ends?"

[^fn19]: If one did not take canary deaths to be an indicator of CO poisoning, and did not care about canary deaths apart from their being a sign of CO levels, one would stop wanting to know about them.

[^cf1]: My arguments do not turn on the specific way of analyzing
the dependence relations that my presentation presupposes.
If for instance the relations are better specified  as in
[@Fig:walter2] in the appendix, I would just have to rephrase [MEP](#mep) and
some of what I've said about extrinsic desires.


[^fn21]: Is the sense of irrationality to be explained by the fact that the person has done something they've no reason to do? No, since this is not inherently irrational; it is rationally permissible to do what one has no reason to do if all of one's alternatives are such that one has no reason to do them either.

[^fn22]: Well, maybe not so fast. See Objection Two.

[^fn23]: That is, he may have been in a position to be moved, but not *rationally* moved.

[^fn24]: *Interlocutor*: would not being *sufficiently* informed mean  not needing or wanting the sign? *Me*: If we understand "sufficient information" in that strong a way, it'll tend to make instrumental desires irrational. Suppose I think Pete's attendance will cause the party to be fun, and hence I want Pete to attend. Would my desire for Pete's attendance survive my being sufficiently informed if that  means knowing whether Pete will attend? *Interlocutor*: Sure. If you knew he won't be there you'd wish he were, and if you knew he'll be there you'd be glad. *Me*: The same can be said about signs. Suppose I want my X-ray to be clear because I believe that would be a sign  I'm cancer free. If I knew that it's clear, I'd be glad, and if it knew it is not, I'd wish it were.

[^fn25]: One might protest that for a desire to be irrational just is for it to be inherently irrational to seek to satisfy. This reduces Objection Two to the nakedly question-begging claim that signatory desires are irrational to seek to satisfy.

[^fn26]: Hume writes, "Where a passion is neither founded on false suppositions, nor chuses means insufficient for the end, the understanding can neither justify nor condemn it."  I suggest that even if the understanding condemns one's desire, it won't condemn taking means sufficient for satisfying it.

[^fn27]: My discussion will be non-technical, but it fits well with the contextualist Karttunen-style semantics [-@KarttunenSSQ] for questions and embedded wh-complements  that @StanleyWilliamsonKH draw on in their account of know-how. 

[^fn28]: Maybe it denotes the set of all S's intrinsic desires, or maybe the set containing the intrinsic desire(s) from which the desire S originally professed ultimately derives.

[^fn29]: This covers Variants 1A and 2A in @Tbl:obj-table.

[^fn30]: If [ESC](#esc) implies that an agent S has a subjective practical reason to do an option O, then S believes doing O would be a sign (but not a cause) of something they desire. Thus, given that [SBD](#sbd) is necessary,  if [ESC](#esc) implies that S has a subjective practical reason to do O, then S desires to do O. But if S desires to do O, then provided that S is minimally rational, S believes that doing O is a means to satisfy one of their desires, since the fact that doing O is a means to its being that case that one does O is analytic.

[^fn31]: This is Variant 1B in @Tbl:obj-table.

[^fn32]: This is Variant 2B in @Tbl:obj-table.

[^fn33]: Saying that extrinsic desires play such roles but are  rationally irrelevant reverts to  Variant 1A, or rather, to something stronger which grants extrinsic desires' status as working desires. I responded to this in @Sec:obj2 and @Sec:obj1.

[^fn34]: An alternative, dialectically equivalent, says his motivation  would come via an intention suitably formed on the basis of the belief(s) just mentioned.

[^fn35]: Notably, the opponent we're
now imagining would hold such motivation to be
*irrational*, since deeming it rational
requires [ESC](#esc), which we're assuming has been
rejected.

[^fn36]: *Interlocutor*: Maybe he "wanted it to happen"---but did he *really want* it to happen? *Me*: Yes! Cf. @Sec:obj4.

[^fn37]: *Interlocutor*: The claim is not that he can be moved by belief alone---but by belief together with his intrinsic desire. *Me*: How can an intrinsic desire help move him to do something he's sure won't lead to its satisfaction?

[^fn38]: And further, no belief that what one is doing is morally required or good.
I am neutral here on whether moral judgments can motivate apart from desire.

[^fn39]: *Interlocutor*: He believes he will get *evidence about* something he wants. Isn't that enough to move him? *Me*: My claim is precisely that he *wants* that evidence, and that that *desire* can move him. My opponent says he *does not want* the evidence.

[^fn40]: Notably, Smith's "suitably related"
qualification, which looks
like a problem for a pure reduction, is
indispensable. This is because it seems possible 
(cf. the "stoic causalist" described earlier) to
have an intrinsic desire and believe that the
truth of some proposition would be a sign or
means to the satisfaction of that desire, and
yet just not want the truth of the proposition
(cf. Smith pp. 97--98). But further, leaving
out 'suitably related' seems to commit one to
something stronger than (the already 
implausible) [SBD](#sbd). 
Whereas SBD is limited to desires 
to do things, the view in
question minus the "suitably related"
qualification would entail that in general,
whenever one has an intrinsic desire and a
belief that the truth of a proposition would be
a sign or cause of that desire's satisfaction,
one thereby has an extrinsic desire for the
truth of the proposition. The resulting
proliferation of (mostly gerrymandered) 
extrinsic desires is unattractive, as they 
would all supposedly count as working rather 
than idle desires (cf. @Sec:workingd).
One avoids this by saying that
only the "suitably related"
belief-plus-intrinsic-desire complexes count as
(working) extrinsic desires.

[^fn41]: Facts about what
people intrinsically desire seem like
they'll ordinarily be subject to a good deal
more indeterminacy than facts about what they
extrinsically desire. Cf. 
@rawlstoj: "whether an aim is final or
derivative is not always easy to ascertain. The
distinction is made on the basis of a person's
rational plan of life and the structure of this
plan is not generally obvious, even to him"
(494).

[^fn42]: I expect that even those who may, on reflection, not be sold on this, can at least appreciate its appeal. If so, then they will, I hope, be interested to see what the broader consequences of embracing it amount to.

[^fn43]: My own intuitions  are easier to state using some concepts I'm about to introduce. I present my intuitions using those concepts in the appendix.

[^cf2]: I intend 'non-decreasing' in this
    sense: letting $w(c,i)$ be weight as a
function of belief confidence and desire
intensity, I assume that if $n$ and $m$ are
non-negative then $w(c,i)\leq w(c+n,i+m)$.

[^fn44]: For convenience, I treat a
one-membered set as interchangeable with
its member and I speak collectively about the
members of a set by speaking of the set.

[^fn45]: It is natural to think of this
    function as summation, but I do not assume
this. I also do not assume favoring is one-one;
a reason might favor two or more options equally---that is, 
it might favor doing any member of a set of
options---or it might favor two or more options 
to different degrees.

[^fn46]: This is meant to be neutral on what thresholds are
appropriate. It can be squared with the view that trumping always occurs by
using the extended reals and taking the appropriate threshold to always be
positive infinity. If appropriate thresholds should ever be finite,
I make no assumptions about what determines them (beyond what I've already
said), or about whether they should be the same for every agent at every time,
or about whether they should be vague. 
What complications arise if they are
treated as vague depends on what theory of vagueness is chosen (e.g., a
trivalent approach requires dealing with  reasons that are neither trumped nor
not trumped). As far as I see, such complications are orthogonal to my claims.

[^fn47]: Note that this is only a sufficient condition. I tend to think there are other kinds of conditions under which it is rationally uncriticizable to ignore trumped reasons.

[^fn48]: This is not to say that the agent cannot be *irrationally* motivated by $\mathbb{R}$. Indeed I would say that they can.

[^fn49]: As briefly discussed in the appendix, I think they can do better than just break ties. I do not assume this in the paper.

[^fn50]: Strictly speaking, one could accept
    [MEP](#mep) as only a sufficient condition
while also accepting [ESC](#esc), and 
conjoin this with
[TLA](#tla). I do not consider such a view
because I reject [ESC](#esc). Cf. @Sec:obj3.

[^fn51]: I'll leave this out hereafter.

[^fn52]: These theories standardly take propositions to be sets of possible worlds.

[^cf3]: For any probability function $\text{Pr}(\bullet)$  and propositions *p* and *q*,  $\text{Pr}(p|q)\stackrel{\text{\tiny def}}{=} \frac{\text{Pr}(p\& q)}{\text{Pr}(q)}$ if $\text{Pr}(q)>0$; otherwise $\text{Pr}(p|q)$ is left undefined.

[^fn53]: This formulation of CDT is due to Skyrms [-@SkyrmsCN; -@SkyrmsPE]. For alternative formulations of CDT, see @gibbardharperCTKEU; Sobel [-@SobelPCC; -@SobelNODT];  @LewisCDT; and @joyce99. As far as I can tell,  my claims do not depend on which version of CDT is chosen.

[^cf4]: Mathematically speaking, it fails whenever there is some option O and state hypotheses $\text{K}_{1}, \text{K}_{2}$  such that $\text{EEU}_{\text{S}}(\text{K}_{1}\& \text{O})\neq \text{EEU}_{\text{S}}(\text{K}_{2}\& \text{O})$ and $\text{Pr}_{\text{S}}(\text{K}_{1}|\text{O})- \text{Pr}_{\text{S}}(\text{K}_{2}|\text{O})\neq \text{Pr}_{\text{S}}(\text{K}_{1})- \text{Pr}_{\text{S}}(\text{K}_{2})$. In other words, in a case where there is an option that provides evidence as to which of $\text{K}_{1}$ or $\text{K}_{2}$ obtains, and which of them obtains affects what the agent cares about, provided that they do O.

[^fn54]: Thinking of CDT and EDT in terms of the "advice" they give to agents is a harmless heuristic.

[^cf5]: Henceforth I will leave the  subscripts out of my notation in footnotes to reduce clutter. $\text{EEU}(\text{1box})=(\text{Pr}(\text{million}|\text{1box})\times \text{EEU}(\text{million}\& \text{1box}))+(\text{Pr}(\text{empty}|\text{1box})\times \text{EEU}(\text{empty}\& \text{1box}))\approx 1000000,$ and $\text{EEU}(\text{2box})=(\text{Pr}_{\text{S}}(\text{million}|\text{2box})\times \text{EEU}(\text{million}\& \text{2box}))+(\text{Pr}(\text{empty}|\text{2box})\times \text{EEU}(\text{empty}\& \text{2box}))\approx 1000.$

[^cf6]: Given any state hypothesis $\text{K}\in \mathbb{K}_{\text{Sally}}$, the conjunction of two-boxing with K has higher evidential expected utility for Sally than the conjunction of one-boxing with K: $\text{CEU}(\text{1box})=(\text{Pr}(\text{million})\times \text{EEU}(\text{million}\& \text{1box}))+(\text{Pr}(\text{empty})\times \text{EEU}(\text{empty}\& \text{1box}))=\text{Pr}(\text{million})1000000,$ and $\text{CEU}(\text{2box})=(\text{Pr}(\text{million})\times \text{EEU}(\text{million}\& \text{2box}))+(\text{Pr}(\text{empty})\times \text{EEU}(\text{empty}\& \text{2box}))=\text{Pr}(\text{million})1001000+\text{Pr}(\text{empty})1000.$

[^cf7]: Assume that for any world $w$, $\text{U}(w)=1$ if Walter receives the million in $w$ and $\text{U}(w)=0$ if Walter does not receive the million in $w.$   Walter can bowl or stay home. EDT says staying home is irrational, since $\text{EEU}(\text{bowl})=(\text{Pr}(\text{million}|\text{bowl})\times \text{EEU}(\text{million}\& \text{bowl}))+(\text{Pr}({\sim} \text{million}|\text{bowl})\times \text{EEU}({\sim} \text{million}\& \text{bowl}))>0$ and $\text{EEU}(\text{home})=(\text{Pr}(\text{million}|\text{home})\times \text{EEU}(\text{million}\& \text{home}))+(\text{Pr}({\sim} \text{million}|\text{home})\times \text{EEU}({\sim} \text{million}\& \text{home}))=0$. CDT says both options are rational, since $\text{CEU}(\text{bowl})=(\text{Pr}(\text{million})\times \text{EEU}(\text{million}\& \text{bowl}))+(\text{Pr}({\sim} \text{million})\times \text{EEU}({\sim} \text{million}\& \text{bowl}))= \text{Pr}(\text{million})$ and $\text{CEU}(\text{home})=(\text{Pr}(\text{million})\times \text{EEU}(\text{million}\& \text{home}))+(\text{Pr}({\sim} \text{million})\times \text{EEU}({\sim} \text{million}\& \text{home}))= \text{Pr}(\text{million})$.

[^cf8]: Supporting this would mean arguing that appropriate thresholds are quite high---after all, Sally's signatory desire has got to be pretty intense! I for one have the intuition that in a case like Newcomb's Problem, the threshold is infinitely high. See the appendix for brief discussion.

[^cf9]: $\text{EEU}(\text{AlleyA})=\sum_{n}n[\text{Pr}(n~\text{hedons}|\text{AlleyA})]\approx 10>\text{EEU}(\text{AlleyB})=\sum_{n}n[\text{Pr}(n~\text{hedons}|\text{AlleyB)}]\approx 9>\text{EEU}(\text{Home})=\sum_{n}n[\text{Pr}(n~\text{hedons}|\text{Home)}]\approx 8$.

[^cf10]: As displayed in @Tbl:dude-table, $\text{CEU}(\text{AlleyA})+8\leq \text{CEU}(\text{AlleyB})=\text{CEU}(\text{Home})$.

[^fn55]: Cf. "conative irrationality" in [@Sec:obj3]. There I was more noncommittal.

[^fn56]: See the appendix for some discussion.

[^fn57]: Here 'M' is short for million and 'T' is short for thousand. Numbers not in italics are Sally's utilities. Her signatory desire intensities are set in italics.

[^fn58]: See the appendix for a proof.

[^fn59]: I agree with @McDanielBradleyDesires in thinking the best way to think of desires that intuitively lack a cancellation condition is as having a trivially false one.

